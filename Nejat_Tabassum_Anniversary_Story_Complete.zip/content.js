const content = {
  photos: [],
  videos: []
};
